/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pss;

/**
 *
 * @author Leket
 */
public class main {

    public static void main(String[] args) {
       
     
       
       Mecanismo m = new Mecanismo(500,false, true, true, true);
       m.verifica();
       
       

       

    }
}
